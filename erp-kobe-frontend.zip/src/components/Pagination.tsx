import React from 'react'

const Pagination = () => {
  return (
    <div>Pagination</div>
  )
}

export default Pagination