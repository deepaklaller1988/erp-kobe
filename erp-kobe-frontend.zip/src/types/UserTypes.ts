export interface userDetailsAttributes {
    accessToken: string;
    email: string;
    id: number
    name: string;
    type: string;
    userId: string;
    verified: boolean;
}